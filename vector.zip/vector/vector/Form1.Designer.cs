﻿namespace vector
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addition = new System.Windows.Forms.Button();
            this.substraction = new System.Windows.Forms.Button();
            this.dotproduct = new System.Windows.Forms.Button();
            this.length = new System.Windows.Forms.Button();
            this.angle = new System.Windows.Forms.Button();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.vectors = new System.Windows.Forms.Label();
            this.txtX1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtY1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtZ1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtX2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtY2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtZ2 = new System.Windows.Forms.TextBox();
            this.lblResult = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // addition
            // 
            this.addition.Location = new System.Drawing.Point(52, 326);
            this.addition.Name = "addition";
            this.addition.Size = new System.Drawing.Size(75, 23);
            this.addition.TabIndex = 0;
            this.addition.Text = "addition";
            this.addition.UseVisualStyleBackColor = true;
            this.addition.Click += new System.EventHandler(this.addition_Click);
            // 
            // substraction
            // 
            this.substraction.Location = new System.Drawing.Point(154, 326);
            this.substraction.Name = "substraction";
            this.substraction.Size = new System.Drawing.Size(75, 23);
            this.substraction.TabIndex = 1;
            this.substraction.Text = "substraction";
            this.substraction.UseVisualStyleBackColor = true;
            this.substraction.Click += new System.EventHandler(this.substraction_Click);
            // 
            // dotproduct
            // 
            this.dotproduct.Location = new System.Drawing.Point(263, 326);
            this.dotproduct.Name = "dotproduct";
            this.dotproduct.Size = new System.Drawing.Size(75, 23);
            this.dotproduct.TabIndex = 2;
            this.dotproduct.Text = "dotproduct";
            this.dotproduct.UseVisualStyleBackColor = true;
            this.dotproduct.Click += new System.EventHandler(this.dotproduct_Click);
            // 
            // length
            // 
            this.length.Location = new System.Drawing.Point(386, 326);
            this.length.Name = "length";
            this.length.Size = new System.Drawing.Size(75, 23);
            this.length.TabIndex = 3;
            this.length.Text = "length";
            this.length.UseVisualStyleBackColor = true;
            this.length.Click += new System.EventHandler(this.length_Click);
            // 
            // angle
            // 
            this.angle.Location = new System.Drawing.Point(500, 326);
            this.angle.Name = "angle";
            this.angle.Size = new System.Drawing.Size(75, 23);
            this.angle.TabIndex = 4;
            this.angle.Text = "angle";
            this.angle.UseVisualStyleBackColor = true;
            this.angle.Click += new System.EventHandler(this.angle_Click);
            // 
            // pictureBox
            // 
            this.pictureBox.Location = new System.Drawing.Point(263, 48);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(156, 88);
            this.pictureBox.TabIndex = 5;
            this.pictureBox.TabStop = false;
            // 
            // vectors
            // 
            this.vectors.AutoSize = true;
            this.vectors.Location = new System.Drawing.Point(323, 154);
            this.vectors.Name = "vectors";
            this.vectors.Size = new System.Drawing.Size(51, 16);
            this.vectors.TabIndex = 6;
            this.vectors.Text = "vectors";
            // 
            // txtX1
            // 
            this.txtX1.Location = new System.Drawing.Point(129, 184);
            this.txtX1.Name = "txtX1";
            this.txtX1.Size = new System.Drawing.Size(100, 22);
            this.txtX1.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 190);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 16);
            this.label1.TabIndex = 8;
            this.label1.Text = "x1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(60, 226);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 16);
            this.label2.TabIndex = 9;
            this.label2.Text = "y1";
            // 
            // txtY1
            // 
            this.txtY1.Location = new System.Drawing.Point(129, 226);
            this.txtY1.Name = "txtY1";
            this.txtY1.Size = new System.Drawing.Size(100, 22);
            this.txtY1.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 268);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "z1";
            // 
            // txtZ1
            // 
            this.txtZ1.Location = new System.Drawing.Point(129, 265);
            this.txtZ1.Name = "txtZ1";
            this.txtZ1.Size = new System.Drawing.Size(100, 22);
            this.txtZ1.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(312, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 16);
            this.label4.TabIndex = 13;
            this.label4.Text = "x2";
            // 
            // txtX2
            // 
            this.txtX2.Location = new System.Drawing.Point(371, 187);
            this.txtX2.Name = "txtX2";
            this.txtX2.Size = new System.Drawing.Size(100, 22);
            this.txtX2.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(312, 226);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 16);
            this.label5.TabIndex = 15;
            this.label5.Text = "y2";
            // 
            // txtY2
            // 
            this.txtY2.Location = new System.Drawing.Point(371, 223);
            this.txtY2.Name = "txtY2";
            this.txtY2.Size = new System.Drawing.Size(100, 22);
            this.txtY2.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(311, 268);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 16);
            this.label6.TabIndex = 17;
            this.label6.Text = "z2";
            // 
            // txtZ2
            // 
            this.txtZ2.Location = new System.Drawing.Point(371, 262);
            this.txtZ2.Name = "txtZ2";
            this.txtZ2.Size = new System.Drawing.Size(100, 22);
            this.txtZ2.TabIndex = 18;
            // 
            // lblResult
            // 
            this.lblResult.Location = new System.Drawing.Point(617, 220);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(100, 22);
            this.lblResult.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(547, 223);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 16);
            this.label7.TabIndex = 20;
            this.label7.Text = "result";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.txtZ2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtY2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtX2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtZ1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtY1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtX1);
            this.Controls.Add(this.vectors);
            this.Controls.Add(this.pictureBox);
            this.Controls.Add(this.angle);
            this.Controls.Add(this.length);
            this.Controls.Add(this.dotproduct);
            this.Controls.Add(this.substraction);
            this.Controls.Add(this.addition);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button addition;
        private System.Windows.Forms.Button substraction;
        private System.Windows.Forms.Button dotproduct;
        private System.Windows.Forms.Button length;
        private System.Windows.Forms.Button angle;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Label vectors;
        private System.Windows.Forms.TextBox txtX1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtY1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtZ1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtX2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtY2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtZ2;
        private System.Windows.Forms.TextBox lblResult;
        private System.Windows.Forms.Label label7;
    }
}

